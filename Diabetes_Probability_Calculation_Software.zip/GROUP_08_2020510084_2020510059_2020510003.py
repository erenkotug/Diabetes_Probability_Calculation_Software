import tkinter as tk
from tkinter import messagebox
import csv
import math


def read_csv(filename):
    with open(filename, mode='r', newline='') as file:
        reader = csv.reader(file)
        headers = next(reader)
        data = [[float(x) for x in row] for row in reader]
    return headers, data


def write_csv(filename, headers, data):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(data)


def check_missing_values(data, headers):
    for row in data:
        if len(row) != len(headers):
            print("There is a missing value")
            return True
    return False


def min_max_values(data):
    min_vals = [float('inf')] * len(data[0])
    max_vals = [-float('inf')] * len(data[0])
    for row in data:
        for i in range(len(row)):
            min_vals[i] = min(min_vals[i], row[i])
            max_vals[i] = max(max_vals[i], row[i])
    return min_vals, max_vals


def check_input(values, min_vals, max_vals):
    for i in range(len(values)):
        if values[i] < min_vals[i] or values[i] > max_vals[i]:
            return False
    return True


def normalize_data(data, min_vals, max_vals):
    for row in data:
        for i in range(len(row) - 1):
            if max_vals[i] != min_vals[i]:
                row[i] = (row[i] - min_vals[i]) / (max_vals[i] - min_vals[i])
            else:
                row[i] = 0.0


def normalize_input_data(inputs, min_vals, max_vals):
    for i in range(len(inputs)):
        if max_vals[i] != min_vals[i]:
            inputs[i] = (inputs[i] - min_vals[i]) / (max_vals[i] - min_vals[i])
        else:
            inputs[i] = 0.0


def euclidean_distance(input_data, data):
    distances = []
    for row in data:
        distance = math.sqrt(sum((row[i] - input_data[i]) ** 2 for i in range(len(input_data))))
        distances.append([distance, row[-1]])
    distances.sort(key=lambda x: x[0])
    return distances


def calculate_rate_of_diabetes(distances):
    return sum(distances[i][1] for i in range(5)) * 20


def on_submit():
    inputs = []
    for entry in entries:
        try:
            inputs.append(float(entry.get()))
        except ValueError:
            messagebox.showerror("Invalid input", "Please enter valid numeric values")
            return

    if not check_input(inputs, min_vals, max_vals):
        messagebox.showerror("Invalid input", "Values are out of range")
        return

    normalize_input_data(inputs, min_vals, max_vals)
    distances = euclidean_distance(inputs, data)
    rate = calculate_rate_of_diabetes(distances)
    messagebox.showinfo("Result", f"Diabetes Rate: %{rate}")


# File Paths
input_filename = "C:/Users/ulaso/Downloads/diabetes.csv"
output_filename = "C:/Users/ulaso/OneDrive/Masaüstü/diabetes_with_manuel.csv"

headers, data = read_csv(input_filename)

if not check_missing_values(data, headers):
    min_vals, max_vals = min_max_values(data)
    normalize_data(data, min_vals, max_vals)
    write_csv(output_filename, headers, data)


# GUI
root = tk.Tk()
root.title("Diabetes Prediction")

tk.Label(root, text="Enter values:").grid(row=0, columnspan=2)

entries = []
for i, header in enumerate(headers[:-1]):
    tk.Label(root, text=header).grid(row=i + 1, column=0)
    entry = tk.Entry(root)
    entry.grid(row=i + 1, column=1)
    entries.append(entry)

submit_button = tk.Button(root, text="Submit", command=on_submit)
submit_button.grid(row=len(headers), columnspan=2)

root.mainloop()
